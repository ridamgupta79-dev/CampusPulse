
from fastapi import FastAPI

from app.core.config import settings
from app.api.routes.students import router as students_router
from app.api.routes.recommendations import (
    router as recommendations_router,
)
from app.api.routes.interventions import router as interventions_router
from app.api.routes.analytics import router as analytics_router
from app.api.routes.auth import router as auth_router, seed_demo_users
from app.db.base import Base
from app.db.session import engine, SessionLocal
from app import models  # noqa: F401
from app.api.routes.risk_assessments import (
    router as risk_assessments_router,
)


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "A student-success platform for explainable risk signals, "
        "coordinated interventions, and measurable follow-up outcomes."
    ),
)


# Initialize tables and local demo identities.
@app.on_event("startup")
def initialize_database() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_demo_users(db)
    finally:
        db.close()

# Register API routers.
app.include_router(auth_router, prefix=settings.api_prefix)
app.include_router(
    students_router,
    prefix=settings.api_prefix,
)

app.include_router(
    recommendations_router,
    prefix=settings.api_prefix,
)

app.include_router(
    interventions_router,
    prefix=settings.api_prefix,
)

app.include_router(
    analytics_router,
    prefix=settings.api_prefix,
)

app.include_router(
    risk_assessments_router,
    prefix=settings.api_prefix,
)


@app.get(f"{settings.api_prefix}/health", tags=["System"])
def health_check() -> dict[str, str]:
    """Check whether the API is running."""
    return {
        "status": "healthy",
        "app": settings.app_name,
        "version": settings.app_version,
    }


@app.get("/", tags=["System"])
def root() -> dict[str, str]:
    """Return basic API information."""
    return {
        "message": "CampusPulse API is running.",
        "health": f"{settings.api_prefix}/health",
        "docs": "/docs",
    }
