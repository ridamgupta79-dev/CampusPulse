"""Centralized demo-role visibility rules for CampusPulse.

These rules are a prototype policy layer, not production authentication.
"""

from fastapi import Header, HTTPException


VISIBLE_SIGNAL_DOMAINS: dict[str, frozenset[str]] = {
    "faculty": frozenset({
        "attendance",
        "academics",
        "participation",
        "faculty_feedback",
    }),
    "mentor": frozenset({
        "attendance",
        "academics",
        "participation",
        "skills",
        "faculty_feedback",
    }),
    "hod": frozenset({
        "attendance",
        "academics",
        "participation",
        "skills",
        "faculty_feedback",
    }),
    "counsellor": frozenset(),
    "finance": frozenset({"fees"}),
    "placement": frozenset({"academics", "skills"}),
}


def get_visible_signal_domains(role: str) -> frozenset[str]:
    """Return the signal domains a recognized demo role may access."""
    normalized_role = role.strip().lower()

    if normalized_role not in VISIBLE_SIGNAL_DOMAINS:
        raise ValueError(f"Unknown demo role: {role}")

    return VISIBLE_SIGNAL_DOMAINS[normalized_role]


def can_view_signal(role: str, domain: str) -> bool:
    """Check whether a demo role may view a signal domain."""
    return domain.strip().lower() in get_visible_signal_domains(role)


def get_current_demo_role(
    x_demo_role: str = Header(
        default="",
        alias="X-Demo-Role",
    ),
) -> str:
    """Validate the demo role supplied in an API request.

    This is a prototype role selector, not authentication.
    """
    role = x_demo_role.strip().lower()

    if role not in VISIBLE_SIGNAL_DOMAINS:
        raise HTTPException(
            status_code=403,
            detail="A valid X-Demo-Role header is required.",
        )

    return role


# Each signal domain is associated with its permitted purpose.
# Domains without a mapping are hidden by default.
PURPOSE_BY_DOMAIN: dict[str, str] = {
    "attendance": "academic_support",
    "academics": "academic_support",
    "participation": "academic_support",
    "faculty_feedback": "academic_support",
    "skills": "placement_support",
    "fees": "finance_support",
}


def can_view_signal_with_consent(
    role: str,
    domain: str,
    consent_status_by_purpose: dict[str, str],
) -> bool:
    """Require both role permission and explicitly granted consent."""
    normalized_domain = domain.strip().lower()
    required_purpose = PURPOSE_BY_DOMAIN.get(normalized_domain)

    if required_purpose is None:
        return False

    if not can_view_signal(role, normalized_domain):
        return False

    consent_status = consent_status_by_purpose.get(
        required_purpose,
        "unknown",
    )

    return consent_status.strip().lower() == "granted"


# Roles allowed to review recommendations for each intended staff role.
# HOD can review across categories as a demo oversight role.
RECOMMENDATION_REVIEW_ROLES: dict[str, frozenset[str]] = {
    "faculty": frozenset({"faculty", "mentor", "hod"}),
    "mentor": frozenset({"faculty", "mentor", "hod"}),
    "hod": frozenset({"hod"}),
    "counsellor": frozenset({"counsellor", "hod"}),
    "finance": frozenset({"finance", "hod"}),
    "placement": frozenset({"placement", "hod"}),
}


def can_review_recommendation(
    actor_role: str,
    intended_role: str,
) -> bool:
    """Check whether a demo role may review a recommendation.

    This is an authorization policy for the prototype, not authentication.
    """
    normalized_actor = actor_role.strip().lower()
    normalized_intended = intended_role.strip().lower()

    if normalized_actor not in VISIBLE_SIGNAL_DOMAINS:
        return False

    allowed_roles = RECOMMENDATION_REVIEW_ROLES.get(normalized_intended)

    if allowed_roles is None:
        return False

    return normalized_actor in allowed_roles

