
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_follow_up_requires_demo_role():
    response = client.post(
        "/api/interventions/1/follow-up",
        json={"note": "Follow-up session completed."},
    )
    assert response.status_code == 403


def test_status_update_requires_demo_role():
    response = client.patch(
        "/api/interventions/1/status",
        json={"status": "in_progress"},
    )
    assert response.status_code == 403


def test_follow_up_returns_not_found_for_unknown_intervention():
    response = client.post(
        "/api/interventions/999999/follow-up",
        headers={"X-Demo-Role": "faculty"},
        json={"note": "Follow-up session completed."},
    )
    assert response.status_code == 404


def test_status_update_returns_not_found_for_unknown_intervention():
    response = client.patch(
        "/api/interventions/999999/status",
        headers={"X-Demo-Role": "faculty"},
        json={"status": "in_progress"},
    )
    assert response.status_code == 404


def test_follow_up_rejects_blank_note():
    response = client.post(
        "/api/interventions/1/follow-up",
        headers={"X-Demo-Role": "faculty"},
        json={"note": "   "},
    )
    assert response.status_code == 422


def test_status_update_rejects_unknown_status():
    response = client.patch(
        "/api/interventions/1/status",
        headers={"X-Demo-Role": "faculty"},
        json={"status": "punished"},
    )
    assert response.status_code == 422

def test_list_interventions_requires_demo_role():
    response = client.get("/api/interventions")
    assert response.status_code == 403


def test_list_interventions_returns_visible_records():
    response = client.get(
        "/api/interventions",
        headers={"X-Demo-Role": "faculty"},
    )

    assert response.status_code == 200, response.text
    assert isinstance(response.json(), list)

    for item in response.json():
        assert "student_name" in item
        assert "student_code" in item
        assert "assigned_owner" in item
        assert "due_date" in item
        assert "status" in item